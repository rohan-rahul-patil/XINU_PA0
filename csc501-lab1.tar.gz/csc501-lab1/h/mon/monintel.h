#ifndef _MONINTEL_H_
#define _MONINTEL_H_

/* Information for using the Intel Pro/100 S PCI card */

#ifndef _INTEL_PRO_100
#define _INTEL_PRO_100

#define _INTEL_VENDOR_ID	    0x8086
#define _INTEL_PRO100_DEVICE_ID	    0x1229

#endif /* _INTEL_PRO_100 */

#endif
